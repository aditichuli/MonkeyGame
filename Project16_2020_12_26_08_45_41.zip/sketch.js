var monkey, monkey_running
var banana, bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup, obstacle1 ,obstacle2,obstacle3 ,obstacle4 ,obstacle5 ,obstacle6;
var score
var survivalTime = 0;

function preload() {


  monkey_running = loadAnimation("sprite_0.png", "sprite_1.png", "sprite_2.png", "sprite_3.png", "sprite_4.png", "sprite_5.png", "sprite_6.png", "sprite_7.png", "sprite_8.png")

  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");

}



function setup() {
  // creating monkey
  monkey = createSprite(80, 315, 20, 20);
  monkey.addAnimation("monkey1", monkey_running);
  monkey.scale = 0.1;


  ground = createSprite(400, 350, 900, 10);
  ground.velocityX = -4
  ground.x = ground.width / 2;
  console.log(ground.x);
  if (frameCount % 60 === 0) {
    banana = createSprite(50, 160, 20, 50);
    banana.y = Math.round(random(80, 120));
    banana.addAnimation("banana", bananaImage);
    banana.addImage(bananaImage);
    banana.scale = 0.1;
    banana.velocityX = -3;
 //set lifetime of the Obstacles so that they are never destyoyed
    
   obstaclesGroup.setLifetime(-1);
    obstaclesGroup.setVelocity(0);
// create Obstacles Group
    obstaclesGroup = cretegroup();
    
if (frameCount % 60 === 0) {
      obstacle = createSprite(330, 330, 50, 50);
      obstacle.velocityX = -(6 + score / 100);
      //generate  random obstacles
      var rand = Math.round(random(1, 6));
      switch (rand) {
        case 1:obstacle.addImage(obstacle1);
          break;
        case 2:obstacle.addImage(obstacle2);
          break;
        case 3:obstacle.addImage(obstacle3);
          break;
        case 4:obstacle.addImage(obstacle4);
          break;
        case 5:obstacle.addImage(obstacle5);
          break;
        case 6:obstacle.addImage(obstacle6);
          break;
        default: break;

         
      }

      //assign scale and lifetime to the obstacle
      obstacle.scale = 0.5;
       obstacle.lifetime = 300;
obstaclesGroup.add(obstacle);
    }
  }
}


function draw() {
  background(255);

  if (ground.x < 0) {
    ground.x = ground.width / 2;

  }

  if (keyDown("space")) {
    monkey.velocityY = -12;

  }
  monkey.velocityY = monkey.velocityY + 0.8;

  monkey.collide(ground);

  drawSprites();
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: " + score, 500, 50);

  stroke("black");
  textSize(20);
  fill("black");
  survivalTime = Math.ceil(frameCount / frameRate())
  text("survival Time: " + survivalTime, 100, 50)






}